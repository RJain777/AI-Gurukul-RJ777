# Workshop prompts — AI Gurukul RJ777 App workshop, developed by Ravindra Jain

# Workshop prompts — paste into any free AI assistant (Claude, ChatGPT, Gemini, Copilot)

Tip: paste the relevant file with each prompt, ask for the complete updated file, and run the tests after every change.

## 1 · Plan
I want to build a small web app called TeamNotes for a team of 20. Users sign in, keep private notes; admins manage users and see a security panel. Write: user stories, the data model (tables and columns), the API endpoints with method, path, who can call it and what it returns, and the security requirements. Keep it small enough to build in one day.

## 2 · Front end
Write a single-page front end in plain HTML, CSS and JavaScript (no framework) with: a sign-in panel, a create-account panel, a notes view, an admin panel and a security panel. Rules: render all server text with textContent (never innerHTML); send JSON with fetch; send an X-CSRF-Token header on every POST, PATCH and DELETE; no inline scripts or styles (we use a strict Content-Security-Policy).

## 3 · Back end
Write a Flask JSON API for the endpoints in the plan. Validate and length-limit every input, return clear JSON errors with correct HTTP status codes, and keep each route short.

## 4 · Database
Add SQLite with tables users, notes, login_attempts and audit_log. Use parameterised queries only. Show the CREATE TABLE statements with constraints and indexes.

## 5 · Login and authentication
Add registration and sign-in: hash passwords with werkzeug's generate_password_hash, start a fresh session on login, set HttpOnly and SameSite=Lax cookies (Secure in production), return the same error for wrong email or wrong password, lock an account for 15 minutes after 5 failures, and enforce a 12-character password policy.

## 6 · Admin panel
Add role-based access: an admin_required decorator, admin endpoints to list, create, update role/status and delete users, and safeguards so an admin can't demote, disable or delete themselves. Log every admin action to audit_log.

## 7 · Security and the security panel
Add CSRF protection, security headers (Content-Security-Policy, X-Content-Type-Options, X-Frame-Options, Referrer-Policy, HSTS in production), and an admin-only security panel endpoint returning 24-hour login stats, locked accounts with an unlock action, top failing IPs, configuration checks and the latest audit events.

## 8 · Review and test
Review this code as a security engineer against the OWASP Top 10. List every issue with severity and the exact fix. Then write tests with Flask's test client for each feature and each security control.
