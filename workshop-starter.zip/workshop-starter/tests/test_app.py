"""Run:  python tests/test_app.py   (or: pytest -q)
Exercises every feature and every security control of TeamNotes against a throwaway database."""
import os, sys, tempfile, importlib
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
TMP = tempfile.mkdtemp()
os.environ.update(DB_PATH=os.path.join(TMP, "test.db"), ADMIN_EMAIL="admin@example.com",
                  ADMIN_PASSWORD="Admin-pass-2026", SECRET_KEY="test-secret")
import app as appmod
importlib.reload(appmod)
app = appmod.app

def client(): return app.test_client()
def login(c, email, pw):
    r = c.post("/api/login", json={"email": email, "password": pw})
    return r, (r.get_json() or {}).get("user", {}).get("csrf")

def test_security_headers():
    r = client().get("/")
    for h in ("Content-Security-Policy", "X-Content-Type-Options", "X-Frame-Options", "Referrer-Policy"):
        assert h in r.headers, h

def test_register_and_password_policy():
    c = client()
    assert c.post("/api/register", json={"email": "a@b.co", "name": "A", "password": "short"}).status_code == 400
    assert c.post("/api/register", json={"email": "user1@example.com", "name": "User One",
                                         "password": "Correct-horse-42"}).status_code == 201
    assert c.post("/api/register", json={"email": "user1@example.com", "name": "Dup",
                                         "password": "Correct-horse-42"}).status_code == 409

def test_login_messages_do_not_leak():
    c = client()
    r1, _ = login(c, "user1@example.com", "wrong-password-1")
    r2, _ = login(c, "nobody@example.com", "wrong-password-1")
    assert r1.status_code == r2.status_code == 401
    assert r1.get_json()["error"] == r2.get_json()["error"]          # same message either way

def test_sql_injection_attempt_fails():
    r, _ = login(client(), "' OR 1=1 --", "anything")
    assert r.status_code == 401

def test_csrf_required_and_notes():
    c = client(); r, csrf = login(c, "user1@example.com", "Correct-horse-42")
    assert r.status_code == 200 and csrf
    assert c.post("/api/notes", json={"title": "x"}).status_code == 403                       # no token
    assert c.post("/api/notes", json={"title": "x"}, headers={"X-CSRF-Token": "bad"}).status_code == 403
    xss = "<script>alert(1)</script>"
    assert c.post("/api/notes", json={"title": xss, "body": "b"}, headers={"X-CSRF-Token": csrf}).status_code == 201
    notes = c.get("/api/notes").get_json()["notes"]
    assert notes[0]["title"] == xss          # stored as plain text; the front end renders it with textContent

def test_users_cannot_reach_admin_or_others_notes():
    c = client(); _, csrf = login(c, "user1@example.com", "Correct-horse-42")
    assert c.get("/api/admin/users").status_code == 403
    assert c.get("/api/admin/security").status_code == 403
    c2 = client(); c2.post("/api/register", json={"email": "user2@example.com", "name": "Two", "password": "Second-user-77"})
    _, csrf2 = login(c2, "user2@example.com", "Second-user-77")
    nid = c2.post("/api/notes", json={"title": "mine"}, headers={"X-CSRF-Token": csrf2}).get_json()["id"]
    assert c.delete(f"/api/notes/{nid}", headers={"X-CSRF-Token": csrf}).status_code == 404   # not user1's note

def test_lockout_after_failed_logins():
    c = client()
    for _ in range(appmod.MAX_FAILS):
        login(c, "user2@example.com", "wrong-wrong-1")
    r, _ = login(c, "user2@example.com", "Second-user-77")           # correct password, but locked
    assert r.status_code == 429

def test_admin_panel_and_security_panel():
    c = client(); r, csrf = login(c, "admin@example.com", "Admin-pass-2026")
    assert r.get_json()["user"]["role"] == "admin"
    users = c.get("/api/admin/users").get_json()["users"]
    u1 = next(u for u in users if u["email"] == "user1@example.com")
    admin = next(u for u in users if u["email"] == "admin@example.com")
    H = {"X-CSRF-Token": csrf}
    assert c.patch(f"/api/admin/users/{admin['id']}", json={"role": "user"}, headers=H).status_code == 400   # not self
    assert c.patch(f"/api/admin/users/{u1['id']}", json={"active": False}, headers=H).status_code == 200
    r, _ = login(client(), "user1@example.com", "Correct-horse-42")
    assert r.status_code == 401                                        # disabled users can't sign in
    sec = c.get("/api/admin/security").get_json()
    assert any(l["email"] == "user2@example.com" for l in sec["locked"])
    assert sec["stats"]["logins_failed_24h"] >= appmod.MAX_FAILS
    assert any(e["event"] == "access_denied" for e in sec["events"])
    assert c.post("/api/admin/security/unlock", json={"email": "user2@example.com"}, headers=H).status_code == 200
    r, _ = login(client(), "user2@example.com", "Second-user-77")
    assert r.status_code == 200                                        # unlocked
    assert c.post("/api/admin/users", json={"email": "new@example.com", "name": "New", "password": "Brand-new-pass-1",
                                            "role": "user"}, headers=H).status_code == 201

def test_logout_clears_session():
    c = client(); _, csrf = login(c, "admin@example.com", "Admin-pass-2026")
    c.post("/api/logout", headers={"X-CSRF-Token": csrf})
    assert c.get("/api/me").get_json()["user"] is None
    assert c.get("/api/notes").status_code == 401

if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items(), key=lambda kv: list(globals()).index(kv[0])) if k.startswith("test_")]
    for t in tests:
        t(); print("PASS", t.__name__)
    print(f"\nAll {len(tests)} tests passed.")
