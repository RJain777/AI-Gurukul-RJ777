/* TeamNotes — developed by Ravindra Jain · © 2026 · MIT licence (see LICENSE) */
/* TeamNotes front end. All server text is written with textContent, never innerHTML,
   so user input can't run as script (XSS). Every change request sends the CSRF token. */
"use strict";
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
let me = null;

async function api(path, { method = "GET", data } = {}) {
  const headers = { "Accept": "application/json" };
  if (data !== undefined) headers["Content-Type"] = "application/json";
  if (method !== "GET" && me) headers["X-CSRF-Token"] = me.csrf;
  const res = await fetch(path, { method, headers, credentials: "same-origin",
                                  body: data !== undefined ? JSON.stringify(data) : undefined });
  const json = await res.json().catch(() => ({}));
  if (res.status === 401 && path !== "/api/login") { me = null; show("login"); }
  if (!res.ok) throw new Error(json.error || `Request failed (${res.status})`);
  return json;
}

function el(tag, text, cls) { const e = document.createElement(tag); if (text != null) e.textContent = text; if (cls) e.className = cls; return e; }
function when(ts) { return new Date(ts * 1000).toLocaleString(); }
function msg(id, text, ok = false) { const m = $(id); m.textContent = text; m.classList.toggle("ok", ok); }

function show(view) {
  ["login", "register", "notes", "admin", "security"].forEach(v => $("#v-" + v).classList.toggle("hidden", v !== view));
  const signedIn = !!me;
  $("#nav").classList.toggle("hidden", !signedIn);
  $("#who").classList.toggle("hidden", !signedIn);
  $$(".admin-only").forEach(b => b.classList.toggle("hidden", !(me && me.role === "admin")));
  $$("#nav button").forEach(b => b.classList.toggle("on", b.dataset.view === view));
  if (signedIn) $("#whoName").textContent = `${me.name} (${me.role})`;
  if (view === "notes") loadNotes();
  if (view === "admin") loadUsers();
  if (view === "security") loadSecurity();
}

/* ── login panel ── */
$("#loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  const f = new FormData(e.target);
  try {
    const r = await api("/api/login", { method: "POST", data: { email: f.get("email"), password: f.get("password") } });
    me = r.user; e.target.reset(); msg("#loginMsg", ""); show("notes");
  } catch (err) { msg("#loginMsg", err.message); }
});
$("#registerForm").addEventListener("submit", async e => {
  e.preventDefault();
  const f = new FormData(e.target);
  try {
    await api("/api/register", { method: "POST", data: Object.fromEntries(f) });
    e.target.reset(); show("login"); msg("#loginMsg", "Account created — sign in.", true);
  } catch (err) { msg("#registerMsg", err.message); }
});
$("#toRegister").onclick = () => show("register");
$("#toLogin").onclick = () => show("login");
$("#logout").onclick = async () => { await api("/api/logout", { method: "POST" }).catch(() => {}); me = null; show("login"); };
$$("#nav button").forEach(b => b.onclick = () => show(b.dataset.view));

/* ── notes ── */
async function loadNotes() {
  const box = $("#notes"); box.replaceChildren();
  const { notes } = await api("/api/notes");
  if (!notes.length) box.append(el("p", "No notes yet.", "muted"));
  notes.forEach(n => {
    const c = el("article", null, "card note");
    c.append(el("h3", n.title), el("p", n.body), el("small", when(n.created), "muted"));
    const del = el("button", "Delete", "ghost");
    del.onclick = async () => { await api(`/api/notes/${n.id}`, { method: "DELETE" }); loadNotes(); };
    c.append(del); box.append(c);
  });
}
$("#noteForm").addEventListener("submit", async e => {
  e.preventDefault();
  try { await api("/api/notes", { method: "POST", data: Object.fromEntries(new FormData(e.target)) });
        e.target.reset(); msg("#noteMsg", ""); loadNotes(); }
  catch (err) { msg("#noteMsg", err.message); }
});

/* ── admin panel ── */
async function loadUsers() {
  const tb = $("#users"); tb.replaceChildren();
  const { users } = await api("/api/admin/users");
  users.forEach(u => {
    const tr = el("tr");
    tr.append(el("td", u.name), el("td", u.email), el("td", u.role),
              el("td", u.active ? "active" : "disabled", u.active ? "good" : "bad"), el("td", String(u.notes)));
    const act = el("td", null, "actions");
    if (u.id !== me.id) {
      const role = el("button", u.role === "admin" ? "Make user" : "Make admin", "ghost");
      role.onclick = () => change(u.id, { role: u.role === "admin" ? "user" : "admin" });
      const st = el("button", u.active ? "Disable" : "Enable", "ghost");
      st.onclick = () => change(u.id, { active: !u.active });
      const del = el("button", "Delete", "danger");
      del.onclick = async () => { if (confirm(`Delete ${u.email}? This removes their notes too.`)) {
        await api(`/api/admin/users/${u.id}`, { method: "DELETE" }); loadUsers(); } };
      act.append(role, st, del);
    } else act.append(el("span", "you", "muted"));
    tr.append(act); tb.append(tr);
  });
}
async function change(id, data) {
  try { await api(`/api/admin/users/${id}`, { method: "PATCH", data }); loadUsers(); }
  catch (err) { msg("#userMsg", err.message); }
}
$("#userForm").addEventListener("submit", async e => {
  e.preventDefault();
  try { await api("/api/admin/users", { method: "POST", data: Object.fromEntries(new FormData(e.target)) });
        e.target.reset(); msg("#userMsg", "User added.", true); loadUsers(); }
  catch (err) { msg("#userMsg", err.message); }
});

/* ── security panel ── */
async function loadSecurity() {
  const s = await api("/api/admin/security");
  const stats = $("#secStats"); stats.replaceChildren();
  [["Successful logins (24h)", s.stats.logins_ok_24h], ["Failed logins (24h)", s.stats.logins_failed_24h],
   ["Access denied (24h)", s.stats.denied_24h], ["Users", s.stats.users], ["Admins", s.stats.admins],
   ["Disabled accounts", s.stats.disabled]].forEach(([label, n]) => {
    const c = el("div", null, "stat"); c.append(el("b", String(n)), el("span", label)); stats.append(c);
  });
  const ck = $("#secChecks"); ck.replaceChildren();
  s.checks.forEach(c => ck.append(el("li", (c.ok ? "✓ " : "✗ ") + c.name, c.ok ? "good" : "bad")));
  const lk = $("#secLocked"); lk.replaceChildren();
  if (!s.locked.length) lk.append(el("p", "No accounts are locked.", "muted"));
  s.locked.forEach(l => {
    const row = el("div", null, "row");
    row.append(el("span", `${l.email} — ${l.fails} failures, last ${when(l.last)}`));
    const b = el("button", "Unlock", "ghost");
    b.onclick = async () => { await api("/api/admin/security/unlock", { method: "POST", data: { email: l.email } }); loadSecurity(); };
    row.append(b); lk.append(row);
  });
  const ips = $("#secIps"); ips.replaceChildren();
  if (!s.top_ips.length) ips.append(el("p", "None.", "muted"));
  s.top_ips.forEach(i => ips.append(el("p", `${i.ip}: ${i.fails} failed logins`)));
  const ev = $("#secEvents"); ev.replaceChildren();
  s.events.forEach(x => { const tr = el("tr");
    tr.append(el("td", when(x.ts)), el("td", x.actor || "—"), el("td", x.event, /fail|denied|locked|deleted|disabled/.test(x.event) ? "bad" : ""),
              el("td", x.detail || ""), el("td", x.ip || "")); ev.append(tr); });
}

/* ── start ── */
api("/api/me").then(r => { me = r.user; show(me ? "notes" : "login"); }).catch(() => show("login"));
