# TeamNotes — workshop starter app

**Developed by Ravindra Jain** · part of *AI Gurukul RJ777 — AI Learning Atlas* · © 2026 Ravindra Jain · MIT licence (see `LICENSE`)

A small but complete web app for the **"Build an end-to-end app with free AI tools"** workshop in the AI Gurukul RJ777 portal (Build lab → App workshop).

| Part | What's here |
|---|---|
| Front end | `static/index.html`, `static/app.js`, `static/styles.css` — no framework |
| Back end | `app.py` — Flask JSON API |
| Database | SQLite, created automatically (`teamnotes.db`) |
| Login panel | Sign in and create-account screens |
| Authentication | scrypt-hashed passwords, server-side session cookie, lockout after 5 failed logins |
| Admin panel | Add users, change roles, enable/disable, delete |
| Security panel | Login stats, locked accounts with unlock, top failing IPs, security checks, audit log |
| Security | CSRF tokens, security headers (CSP etc.), parameterised SQL, XSS-safe rendering, password policy |
| Tests | `tests/test_app.py` — 9 tests covering every feature and security control |

## Run it (Windows PowerShell)

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:ADMIN_EMAIL="admin@example.com"; $env:ADMIN_PASSWORD="Choose-a-strong-pass-1"; $env:SECRET_KEY="any-long-random-text"
python app.py
```
Open http://127.0.0.1:5000 and sign in with the admin details. (macOS/Linux: `source .venv/bin/activate` and `export VAR=value`.)

## Test it

```bash
python tests/test_app.py
```

## Deploy it (free tiers — check each provider's current limits)

1. Push this folder to a GitHub repository (never commit `.env` or `teamnotes.db`).
2. Create a web service on a host with a free tier (for example Render or PythonAnywhere).
3. Start command: `gunicorn app:app` (add `gunicorn` to `requirements.txt`).
4. Set environment variables: `APP_ENV=production`, a long random `SECRET_KEY`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`.
5. Free hosts often wipe local files on redeploy or sleep — for real use, move the data to a managed Postgres database.

## Change it with AI

`PROMPTS.md` has the prompts used in the workshop, one per module. Paste them into any free AI assistant together with the relevant file.

Synthetic data only — don't put real company or customer data into a learning project.

## Licence

MIT — © 2026 Ravindra Jain. Keep the copyright notice in any copy or adaptation.
