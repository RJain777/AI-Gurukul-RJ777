"""
TeamNotes — developed by Ravindra Jain for the AI Gurukul RJ777 workshop. © 2026 Ravindra Jain · MIT licence (see LICENSE).

TeamNotes — a small, complete web app for the AI Gurukul RJ777 "Build an app with free AI tools" workshop.

  Front end   static/index.html + static/app.js + static/styles.css (no framework)
  Back end    Flask JSON API (this file)
  Database    SQLite (teamnotes.db, created automatically)
  Auth        email + password, scrypt-hashed, server-side session cookie
  Roles       user, admin  (admin panel + security panel)
  Security    CSRF token, lockout after failed logins, security headers,
              parameterised SQL, audit log, password policy

Run locally:
    pip install -r requirements.txt
    set ADMIN_EMAIL and ADMIN_PASSWORD (first run creates the admin), then
    python app.py            ->  http://127.0.0.1:5000
"""
import os, re, secrets, sqlite3, time
from datetime import timedelta
from functools import wraps
from flask import Flask, g, jsonify, request, session, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash

# ─── configuration ────────────────────────────────────────────────────────────
PRODUCTION = os.environ.get("APP_ENV") == "production"
DB_PATH = os.environ.get("DB_PATH", os.path.join(os.path.dirname(__file__), "teamnotes.db"))
MAX_FAILS, LOCK_MINUTES = 5, 15            # lockout policy
IP_LIMIT = 30                              # failed logins per IP per lock window

app = Flask(__name__, static_folder="static", static_url_path="/static")
secret = os.environ.get("SECRET_KEY")
if PRODUCTION and not secret:
    raise SystemExit("SECRET_KEY must be set in production")
app.config.update(
    SECRET_KEY=secret or secrets.token_hex(32),          # dev only: random per start
    SESSION_COOKIE_HTTPONLY=True,                         # JavaScript can't read the cookie
    SESSION_COOKIE_SAMESITE="Lax",                        # blocks most cross-site requests
    SESSION_COOKIE_SECURE=PRODUCTION,                     # HTTPS-only cookie in production
    PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
    MAX_CONTENT_LENGTH=64 * 1024,                         # reject huge request bodies
)

# ─── database ─────────────────────────────────────────────────────────────────
SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
  pw_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user','admin')),
  active INTEGER NOT NULL DEFAULT 1, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS notes(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL, body TEXT NOT NULL, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS login_attempts(
  id INTEGER PRIMARY KEY, email TEXT NOT NULL, ip TEXT NOT NULL, ok INTEGER NOT NULL, ts REAL NOT NULL);
CREATE TABLE IF NOT EXISTS audit_log(
  id INTEGER PRIMARY KEY, ts REAL NOT NULL, actor TEXT, event TEXT NOT NULL, detail TEXT, ip TEXT);
CREATE INDEX IF NOT EXISTS ix_attempts ON login_attempts(email, ts);
"""

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(_exc):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()

def init_db():
    with app.app_context():
        db().executescript(SCHEMA)
        email, pw = os.environ.get("ADMIN_EMAIL"), os.environ.get("ADMIN_PASSWORD")
        has_admin = db().execute("SELECT 1 FROM users WHERE role='admin'").fetchone()
        if email and pw and not has_admin:
            problem = password_problem(pw, email)
            if problem:
                raise SystemExit(f"ADMIN_PASSWORD rejected: {problem}")
            db().execute("INSERT INTO users(email,name,pw_hash,role,created) VALUES(?,?,?,?,?)",
                         (email.lower(), "Administrator", generate_password_hash(pw), "admin", time.time()))
            db().commit()
            print(f"Created admin {email}")

def audit(event, detail="", actor=None):
    db().execute("INSERT INTO audit_log(ts,actor,event,detail,ip) VALUES(?,?,?,?,?)",
                 (time.time(), actor or session.get("email"), event, detail[:300], client_ip()))
    db().commit()

def client_ip():
    return request.headers.get("X-Forwarded-For", request.remote_addr or "?").split(",")[0].strip()

# ─── validation helpers ───────────────────────────────────────────────────────
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,190}\.[A-Za-z]{2,}$")

def password_problem(pw, email=""):
    if len(pw) < 12:                         return "use at least 12 characters"
    if not re.search(r"[A-Za-z]", pw) or not re.search(r"\d", pw):
        return "include letters and at least one number"
    if email and pw.lower() == email.lower(): return "must not be your email"
    return None

def body():
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}

def clean(text, limit):
    return str(text or "").strip()[:limit]

# ─── security middleware ──────────────────────────────────────────────────────
@app.after_request
def security_headers(resp):
    resp.headers["Content-Security-Policy"] = ("default-src 'self'; script-src 'self'; style-src 'self'; "
                                               "img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'")
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "no-referrer"
    resp.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    if PRODUCTION:
        resp.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    if request.path.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"
    return resp

CSRF_EXEMPT = {"/api/login", "/api/register"}

@app.before_request
def csrf_protect():
    """Every state-changing API call must echo the session's CSRF token in a header."""
    if request.method in ("POST", "PUT", "PATCH", "DELETE") and request.path.startswith("/api/") \
            and request.path not in CSRF_EXEMPT:
        sent = request.headers.get("X-CSRF-Token", "")
        if not sent or not secrets.compare_digest(sent, session.get("csrf", "")):
            return jsonify(error="Missing or invalid CSRF token"), 403

def current_user():
    uid = session.get("uid")
    if not uid:
        return None
    u = db().execute("SELECT id,email,name,role,active FROM users WHERE id=?", (uid,)).fetchone()
    if not u or not u["active"]:
        session.clear()
        return None
    return u

def login_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if not current_user():
            return jsonify(error="Please sign in"), 401
        return fn(*a, **kw)
    return wrapper

def admin_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        u = current_user()
        if not u:
            return jsonify(error="Please sign in"), 401
        if u["role"] != "admin":
            audit("access_denied", request.path)
            return jsonify(error="Admins only"), 403
        return fn(*a, **kw)
    return wrapper

# ─── auth API ─────────────────────────────────────────────────────────────────
def recent_fails(email=None, ip=None):
    since = time.time() - LOCK_MINUTES * 60
    if email:
        q, arg = "SELECT COUNT(*) FROM login_attempts WHERE email=? AND ok=0 AND ts>?", email
    else:
        q, arg = "SELECT COUNT(*) FROM login_attempts WHERE ip=? AND ok=0 AND ts>?", ip
    return db().execute(q, (arg, since)).fetchone()[0]

def start_session(u):
    session.clear()                      # new session on login (prevents session fixation)
    session.permanent = True
    session.update(uid=u["id"], email=u["email"], csrf=secrets.token_urlsafe(32))

def me_payload(u):
    return {"id": u["id"], "email": u["email"], "name": u["name"], "role": u["role"], "csrf": session["csrf"]}

@app.post("/api/register")
def register():
    d = body()
    email, name, pw = clean(d.get("email"), 254).lower(), clean(d.get("name"), 80), str(d.get("password") or "")
    if not EMAIL_RE.match(email):          return jsonify(error="Enter a valid email"), 400
    if not name:                           return jsonify(error="Enter your name"), 400
    problem = password_problem(pw, email)
    if problem:                            return jsonify(error=f"Password: {problem}"), 400
    try:
        db().execute("INSERT INTO users(email,name,pw_hash,created) VALUES(?,?,?,?)",
                     (email, name, generate_password_hash(pw), time.time()))
        db().commit()
    except sqlite3.IntegrityError:
        return jsonify(error="That email is already registered"), 409
    audit("register", email, actor=email)
    return jsonify(ok=True), 201

DUMMY_HASH = generate_password_hash(secrets.token_hex(16))

@app.post("/api/login")
def login():
    d = body()
    email, pw, ip = clean(d.get("email"), 254).lower(), str(d.get("password") or ""), client_ip()
    if recent_fails(email=email) >= MAX_FAILS or recent_fails(ip=ip) >= IP_LIMIT:
        audit("login_locked", email, actor=email)
        return jsonify(error=f"Too many failed attempts. Try again in {LOCK_MINUTES} minutes."), 429
    u = db().execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    # always run a hash check so response time doesn't reveal whether the email exists
    ok = check_password_hash(u["pw_hash"] if u else DUMMY_HASH, pw) and bool(u) and bool(u["active"])
    db().execute("INSERT INTO login_attempts(email,ip,ok,ts) VALUES(?,?,?,?)", (email, ip, int(ok), time.time()))
    db().commit()
    if not ok:
        audit("login_failed", email, actor=email)
        return jsonify(error="Invalid email or password"), 401          # same message either way
    start_session(u)
    audit("login_ok", "", actor=u["email"])
    return jsonify(user=me_payload(u))

@app.post("/api/logout")
def logout():
    if session.get("email"):
        audit("logout")
    session.clear()
    return jsonify(ok=True)

@app.get("/api/me")
def me():
    u = current_user()
    return jsonify(user=me_payload(u) if u else None)

# ─── notes API (any signed-in user, own data only) ────────────────────────────
@app.get("/api/notes")
@login_required
def list_notes():
    rows = db().execute("SELECT id,title,body,created FROM notes WHERE user_id=? ORDER BY created DESC",
                        (session["uid"],)).fetchall()
    return jsonify(notes=[dict(r) for r in rows])

@app.post("/api/notes")
@login_required
def add_note():
    d = body()
    title, text = clean(d.get("title"), 120), clean(d.get("body"), 4000)
    if not title:
        return jsonify(error="Give the note a title"), 400
    cur = db().execute("INSERT INTO notes(user_id,title,body,created) VALUES(?,?,?,?)",
                       (session["uid"], title, text, time.time()))
    db().commit()
    return jsonify(id=cur.lastrowid), 201

@app.delete("/api/notes/<int:nid>")
@login_required
def delete_note(nid):
    cur = db().execute("DELETE FROM notes WHERE id=? AND user_id=?", (nid, session["uid"]))   # own notes only
    db().commit()
    return (jsonify(ok=True), 200) if cur.rowcount else (jsonify(error="Not found"), 404)

# ─── admin panel API ──────────────────────────────────────────────────────────
@app.get("/api/admin/users")
@admin_required
def admin_users():
    rows = db().execute("""SELECT u.id,u.email,u.name,u.role,u.active,u.created,
                           (SELECT COUNT(*) FROM notes n WHERE n.user_id=u.id) AS notes
                           FROM users u ORDER BY u.created""").fetchall()
    return jsonify(users=[dict(r) for r in rows])

@app.post("/api/admin/users")
@admin_required
def admin_create_user():
    d = body()
    email, name, pw = clean(d.get("email"), 254).lower(), clean(d.get("name"), 80), str(d.get("password") or "")
    role = d.get("role") if d.get("role") in ("user", "admin") else "user"
    if not EMAIL_RE.match(email) or not name:
        return jsonify(error="Enter a valid name and email"), 400
    problem = password_problem(pw, email)
    if problem:
        return jsonify(error=f"Password: {problem}"), 400
    try:
        db().execute("INSERT INTO users(email,name,pw_hash,role,created) VALUES(?,?,?,?,?)",
                     (email, name, generate_password_hash(pw), role, time.time()))
        db().commit()
    except sqlite3.IntegrityError:
        return jsonify(error="That email is already registered"), 409
    audit("user_created", f"{email} as {role}")
    return jsonify(ok=True), 201

@app.patch("/api/admin/users/<int:uid>")
@admin_required
def admin_update_user(uid):
    d = body()
    if uid == session["uid"]:
        return jsonify(error="You can't change your own role or status"), 400
    target = db().execute("SELECT email FROM users WHERE id=?", (uid,)).fetchone()
    if not target:
        return jsonify(error="Not found"), 404
    if "role" in d:
        if d["role"] not in ("user", "admin"):
            return jsonify(error="Unknown role"), 400
        db().execute("UPDATE users SET role=? WHERE id=?", (d["role"], uid))
        audit("role_changed", f"{target['email']} -> {d['role']}")
    if "active" in d:
        db().execute("UPDATE users SET active=? WHERE id=?", (1 if d["active"] else 0, uid))
        audit("user_enabled" if d["active"] else "user_disabled", target["email"])
    db().commit()
    return jsonify(ok=True)

@app.delete("/api/admin/users/<int:uid>")
@admin_required
def admin_delete_user(uid):
    if uid == session["uid"]:
        return jsonify(error="You can't delete yourself"), 400
    target = db().execute("SELECT email FROM users WHERE id=?", (uid,)).fetchone()
    if not target:
        return jsonify(error="Not found"), 404
    db().execute("DELETE FROM users WHERE id=?", (uid,))
    db().commit()
    audit("user_deleted", target["email"])
    return jsonify(ok=True)

# ─── security panel API ───────────────────────────────────────────────────────
@app.get("/api/admin/security")
@admin_required
def security_panel():
    day, lock_since = time.time() - 86400, time.time() - LOCK_MINUTES * 60
    q = lambda sql, *a: db().execute(sql, a).fetchone()[0]
    locked = db().execute("""SELECT email, COUNT(*) AS fails, MAX(ts) AS last FROM login_attempts
                             WHERE ok=0 AND ts>? GROUP BY email HAVING COUNT(*)>=? ORDER BY last DESC""",
                          (lock_since, MAX_FAILS)).fetchall()
    top_ips = db().execute("""SELECT ip, COUNT(*) AS fails FROM login_attempts WHERE ok=0 AND ts>?
                              GROUP BY ip ORDER BY fails DESC LIMIT 5""", (day,)).fetchall()
    events = db().execute("SELECT ts,actor,event,detail,ip FROM audit_log ORDER BY id DESC LIMIT 60").fetchall()
    checks = [
        {"name": "Secret key set from environment", "ok": bool(os.environ.get("SECRET_KEY"))},
        {"name": "HTTPS-only session cookie", "ok": app.config["SESSION_COOKIE_SECURE"]},
        {"name": "Debug mode off", "ok": not app.debug},
        {"name": f"Lockout after {MAX_FAILS} failed logins for {LOCK_MINUTES} min", "ok": True},
        {"name": "Passwords hashed with scrypt", "ok": True},
        {"name": "CSRF token on every state-changing request", "ok": True},
        {"name": "Content-Security-Policy and security headers", "ok": True},
    ]
    return jsonify(
        stats={"logins_ok_24h": q("SELECT COUNT(*) FROM login_attempts WHERE ok=1 AND ts>?", day),
               "logins_failed_24h": q("SELECT COUNT(*) FROM login_attempts WHERE ok=0 AND ts>?", day),
               "denied_24h": q("SELECT COUNT(*) FROM audit_log WHERE event='access_denied' AND ts>?", day),
               "users": q("SELECT COUNT(*) FROM users"),
               "admins": q("SELECT COUNT(*) FROM users WHERE role='admin'"),
               "disabled": q("SELECT COUNT(*) FROM users WHERE active=0")},
        locked=[dict(r) for r in locked], top_ips=[dict(r) for r in top_ips],
        events=[dict(r) for r in events], checks=checks)

@app.post("/api/admin/security/unlock")
@admin_required
def unlock():
    email = clean(body().get("email"), 254).lower()
    db().execute("DELETE FROM login_attempts WHERE email=? AND ok=0", (email,))
    db().commit()
    audit("account_unlocked", email)
    return jsonify(ok=True)

# ─── front end ────────────────────────────────────────────────────────────────
@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")

@app.errorhandler(413)
def too_large(_e):
    return jsonify(error="Request too large"), 413

init_db()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)), debug=False)
